/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef, ChangeEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BookOpen, 
  Cpu, 
  Settings, 
  Building2, 
  Zap, 
  Info, 
  Calendar, 
  Image as ImageIcon, 
  Phone, 
  Mail, 
  MapPin, 
  Facebook, 
  Twitter, 
  Instagram, 
  Linkedin,
  Upload,
  User,
  CreditCard,
  Menu,
  X,
  ChevronRight
} from 'lucide-react';

// --- Types ---
interface StudentData {
  fullName: string;
  rollNumber: string;
  branch: string;
  year: string;
  photo: string | null;
}

// --- Components ---

const SplashScreen = ({ onComplete }: { onComplete: () => void }) => {
  const text = "Vignan's LARA";
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(onComplete, 800);
          return 100;
        }
        return prev + 2;
      });
    }, 40);
    return () => clearInterval(timer);
  }, [onComplete]);

  return (
    <motion.div 
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-navy-900"
      exit={{ opacity: 0 }}
      transition={{ duration: 0.8 }}
    >
      <div className="flex mb-8">
        {text.split("").map((char, i) => (
          <motion.span
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1, duration: 0.5 }}
            className="text-4xl md:text-7xl font-display font-bold text-gold-500 gold-glow"
          >
            {char === " " ? "\u00A0" : char}
          </motion.span>
        ))}
      </div>
      <div className="w-64 h-1 bg-navy-800 rounded-full overflow-hidden">
        <motion.div 
          className="h-full bg-gold-500"
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
        />
      </div>
      <motion.p 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="mt-4 text-gold-500/60 font-mono text-sm tracking-widest"
      >
        LOADING EXCELLENCE...
      </motion.p>
    </motion.div>
  );
};

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'Students', href: '#students' },
    { name: 'Departments', href: '#departments' },
    { name: 'Events', href: '#events' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <nav className={`fixed top-0 w-full z-40 transition-all duration-300 ${isScrolled ? 'bg-navy-900/95 backdrop-blur-md py-4 shadow-lg' : 'bg-transparent py-6'}`}>
      <div className="container mx-auto px-6 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-gold-500 rounded-lg flex items-center justify-center font-display font-bold text-navy-900 text-xl">V</div>
          <span className="font-display font-bold text-2xl text-white tracking-tight">LARA<span className="text-gold-500">.</span></span>
        </div>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href} 
              className="text-sm font-medium text-slate-300 hover:text-gold-500 transition-colors uppercase tracking-wider"
            >
              {link.name}
            </a>
          ))}
        </div>

        {/* Mobile Toggle */}
        <button 
          className="md:hidden text-white"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-navy-800 border-b border-navy-700 overflow-hidden"
          >
            <div className="flex flex-col p-6 gap-4">
              {navLinks.map((link) => (
                <a 
                  key={link.name} 
                  href={link.href} 
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="text-lg font-medium text-slate-300 hover:text-gold-500"
                >
                  {link.name}
                </a>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const IDCardGenerator = () => {
  const [student, setStudent] = useState<StudentData>({
    fullName: '',
    rollNumber: '',
    branch: 'CSE',
    year: '1st Year',
    photo: null,
  });
  const [showCard, setShowCard] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handlePhotoUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setStudent({ ...student, photo: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <section id="students" className="py-24 bg-navy-900">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">Digital Identity</h2>
          <p className="text-slate-400 max-w-2xl mx-auto italic">Generate your official Vignan's LARA digital student ID card instantly.</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Form */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-navy-800 p-8 rounded-2xl border border-navy-700 shadow-xl"
          >
            <h3 className="text-2xl font-display font-bold mb-6 text-gold-500 flex items-center gap-2">
              <User className="w-6 h-6" /> Student Details
            </h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1">Full Name</label>
                <input 
                  type="text" 
                  className="w-full bg-navy-900 border border-navy-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-gold-500 transition-colors"
                  placeholder="Enter your full name"
                  value={student.fullName}
                  onChange={(e) => setStudent({ ...student, fullName: e.target.value })}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-400 mb-1">Roll Number</label>
                  <input 
                    type="text" 
                    className="w-full bg-navy-900 border border-navy-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-gold-500 transition-colors"
                    placeholder="e.g. 21FE1A0501"
                    value={student.rollNumber}
                    onChange={(e) => setStudent({ ...student, rollNumber: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-400 mb-1">Branch</label>
                  <select 
                    className="w-full bg-navy-900 border border-navy-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-gold-500 transition-colors"
                    value={student.branch}
                    onChange={(e) => setStudent({ ...student, branch: e.target.value })}
                  >
                    <option>CSE</option>
                    <option>ECE</option>
                    <option>MECH</option>
                    <option>CIVIL</option>
                    <option>EEE</option>
                    <option>IT</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1">Year of Study</label>
                <select 
                  className="w-full bg-navy-900 border border-navy-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-gold-500 transition-colors"
                  value={student.year}
                  onChange={(e) => setStudent({ ...student, year: e.target.value })}
                >
                  <option>1st Year</option>
                  <option>2nd Year</option>
                  <option>3rd Year</option>
                  <option>4th Year</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1">Passport Photo</label>
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full h-32 border-2 border-dashed border-navy-700 rounded-xl flex flex-col items-center justify-center cursor-pointer hover:border-gold-500 transition-colors group"
                >
                  {student.photo ? (
                    <img src={student.photo} alt="Preview" className="h-full w-full object-cover rounded-xl" />
                  ) : (
                    <>
                      <Upload className="w-8 h-8 text-slate-500 group-hover:text-gold-500 mb-2" />
                      <span className="text-sm text-slate-500">Click to upload photo</span>
                    </>
                  )}
                </div>
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  className="hidden" 
                  accept="image/*"
                  onChange={handlePhotoUpload}
                />
              </div>
              <button 
                onClick={() => setShowCard(true)}
                className="w-full bg-gold-500 hover:bg-gold-600 text-navy-900 font-bold py-3 rounded-lg transition-all transform hover:scale-[1.02] active:scale-95 mt-4"
              >
                Generate ID Card
              </button>
            </div>
          </motion.div>

          {/* ID Card Preview */}
          <div className="flex flex-col items-center justify-center">
            <AnimatePresence mode="wait">
              {showCard ? (
                <motion.div 
                  key="id-card"
                  initial={{ opacity: 0, rotateY: 90 }}
                  animate={{ opacity: 1, rotateY: 0 }}
                  className="w-full max-w-sm aspect-[1.58/1] id-card-gradient rounded-2xl border-2 border-gold-500/30 p-6 shadow-2xl relative overflow-hidden flex flex-col"
                >
                  {/* Card Header */}
                  <div className="flex items-center gap-3 mb-6 border-b border-gold-500/20 pb-3">
                    <div className="w-10 h-10 bg-gold-500 rounded flex items-center justify-center font-display font-bold text-navy-900 text-xl">V</div>
                    <div>
                      <h4 className="text-xs font-bold text-white leading-tight">VIGNAN'S LARA</h4>
                      <p className="text-[8px] text-gold-500 tracking-widest font-bold">INSTITUTE OF TECH & SCI</p>
                    </div>
                  </div>

                  {/* Card Content */}
                  <div className="flex gap-6 flex-1">
                    <div className="w-24 h-32 bg-navy-800 rounded-lg border border-gold-500/10 overflow-hidden flex items-center justify-center">
                      {student.photo ? (
                        <img src={student.photo} alt="Student" className="w-full h-full object-cover" />
                      ) : (
                        <User className="w-12 h-12 text-navy-700" />
                      )}
                    </div>
                    <div className="flex-1 space-y-2">
                      <div>
                        <p className="text-[8px] text-gold-500 uppercase font-bold">Full Name</p>
                        <p className="text-sm font-bold text-white uppercase truncate">{student.fullName || 'YOUR NAME'}</p>
                      </div>
                      <div>
                        <p className="text-[8px] text-gold-500 uppercase font-bold">Roll Number</p>
                        <p className="text-sm font-bold text-white uppercase">{student.rollNumber || '21FE1AXXXX'}</p>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <p className="text-[8px] text-gold-500 uppercase font-bold">Branch</p>
                          <p className="text-xs font-bold text-white">{student.branch}</p>
                        </div>
                        <div>
                          <p className="text-[8px] text-gold-500 uppercase font-bold">Year</p>
                          <p className="text-xs font-bold text-white">{student.year}</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Barcode Placeholder */}
                  <div className="mt-4 pt-4 border-t border-gold-500/10 flex justify-between items-end">
                    <div className="flex gap-[2px]">
                      {[...Array(30)].map((_, i) => (
                        <div 
                          key={i} 
                          className="bg-white/80" 
                          style={{ 
                            width: `${Math.random() * 3 + 1}px`, 
                            height: '20px',
                            opacity: Math.random() > 0.3 ? 1 : 0.5
                          }} 
                        />
                      ))}
                    </div>
                    <p className="text-[10px] font-mono text-gold-500/50">STUDENT ID CARD</p>
                  </div>

                  {/* Decorative Elements */}
                  <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-gold-500/5 rounded-full blur-3xl" />
                </motion.div>
              ) : (
                <motion.div 
                  key="placeholder"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="w-full max-w-sm aspect-[1.58/1] bg-navy-800/50 border-2 border-dashed border-navy-700 rounded-2xl flex flex-col items-center justify-center text-slate-500"
                >
                  <CreditCard className="w-16 h-16 mb-4 opacity-20" />
                  <p className="text-sm">Your ID card will appear here</p>
                </motion.div>
              )}
            </AnimatePresence>
            {showCard && (
              <p className="mt-6 text-xs text-slate-500 italic">Screenshot this card for your records.</p>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

const Departments = () => {
  const depts = [
    { name: 'CSE', icon: <Cpu />, desc: 'Computer Science & Engineering focusing on AI, ML, and Data Science.' },
    { name: 'ECE', icon: <Zap />, desc: 'Electronics & Communication Engineering exploring VLSI and Embedded Systems.' },
    { name: 'MECH', icon: <Settings />, desc: 'Mechanical Engineering with advanced robotics and manufacturing labs.' },
    { name: 'CIVIL', icon: <Building2 />, desc: 'Civil Engineering building sustainable infrastructure for the future.' },
    { name: 'EEE', icon: <Zap />, desc: 'Electrical & Electronics Engineering powering the world with clean energy.' },
    { name: 'IT', icon: <BookOpen />, desc: 'Information Technology bridging the gap between business and technology.' },
  ];

  return (
    <section id="departments" className="py-24 bg-navy-800/50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">Our Departments</h2>
          <p className="text-slate-400 max-w-2xl mx-auto italic">Excellence in every discipline, fostering innovation and technical prowess.</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {depts.map((dept, i) => (
            <motion.div 
              key={dept.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ y: -10 }}
              className="bg-navy-800 p-8 rounded-2xl border border-navy-700 hover:border-gold-500/50 transition-all group"
            >
              <div className="w-14 h-14 bg-navy-900 rounded-xl flex items-center justify-center text-gold-500 mb-6 group-hover:bg-gold-500 group-hover:text-navy-900 transition-colors">
                {dept.icon}
              </div>
              <h3 className="text-2xl font-bold mb-3">{dept.name}</h3>
              <p className="text-slate-400 text-sm leading-relaxed">{dept.desc}</p>
              <button className="mt-6 flex items-center gap-2 text-gold-500 font-bold text-sm group-hover:gap-3 transition-all">
                Learn More <ChevronRight className="w-4 h-4" />
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Events = () => {
  const events = [
    { date: 'APR 15', title: 'LARA FIESTA 2026', desc: 'The annual cultural extravaganza featuring music, dance, and arts.' },
    { date: 'MAY 02', title: 'TECH-XPLORE', desc: 'National level technical symposium for engineering students.' },
    { date: 'JUN 10', title: 'ALUMNI MEET', desc: 'Reconnect with your seniors and network with industry leaders.' },
  ];

  return (
    <section id="events" className="py-24 bg-navy-900">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <div className="text-left">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Upcoming Events</h2>
            <p className="text-slate-400 italic">Stay updated with the latest happenings on campus.</p>
          </div>
          <button className="px-8 py-3 border border-gold-500 text-gold-500 rounded-full font-bold hover:bg-gold-500 hover:text-navy-900 transition-all">
            View All Events
          </button>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {events.map((event, i) => (
            <motion.div 
              key={event.title}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="bg-navy-800 rounded-2xl overflow-hidden border border-navy-700 flex flex-col"
            >
              <div className="h-48 bg-navy-900 relative flex items-center justify-center overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-gold-500/20 to-transparent" />
                <Calendar className="w-16 h-16 text-gold-500/20" />
                <div className="absolute top-4 left-4 bg-gold-500 text-navy-900 font-bold px-3 py-1 rounded text-sm">
                  {event.date}
                </div>
              </div>
              <div className="p-6 flex-1">
                <h3 className="text-xl font-bold mb-3">{event.title}</h3>
                <p className="text-slate-400 text-sm">{event.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Gallery = () => {
  const [filter, setFilter] = useState('All');
  
  const categories = ['All', 'Events', 'Sports', 'Academics', 'Campus'];
  
  const images = [
    { src: "https://picsum.photos/seed/lara-event1/800/600", category: "Events", title: "Lara Fiesta" },
    { src: "https://picsum.photos/seed/lara-sports1/800/600", category: "Sports", title: "Cricket Finals" },
    { src: "https://picsum.photos/seed/lara-acad1/800/600", category: "Academics", title: "Tech Symposium" },
    { src: "https://picsum.photos/seed/lara-campus1/800/600", category: "Campus", title: "Main Entrance" },
    { src: "https://picsum.photos/seed/lara-event2/800/600", category: "Events", title: "Cultural Fest" },
    { src: "https://picsum.photos/seed/lara-sports2/800/600", category: "Sports", title: "Basketball" },
    { src: "https://picsum.photos/seed/lara-acad2/800/600", category: "Academics", title: "AI Workshop" },
    { src: "https://picsum.photos/seed/lara-campus2/800/600", category: "Campus", title: "Digital Library" },
    { src: "https://picsum.photos/seed/lara-event3/800/600", category: "Events", title: "Freshers Day" },
  ];

  const filteredImages = filter === 'All' 
    ? images 
    : images.filter(img => img.category === filter);

  return (
    <section id="gallery" className="py-24 bg-navy-800/50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">Campus Life</h2>
          <p className="text-slate-400 max-w-2xl mx-auto italic">Glimpses of our vibrant campus and student achievements.</p>
        </div>

        {/* Filter Buttons */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`px-6 py-2 rounded-full text-sm font-bold transition-all ${
                filter === cat 
                  ? 'bg-gold-500 text-navy-900 shadow-lg shadow-gold-500/20' 
                  : 'bg-navy-800 text-slate-400 border border-navy-700 hover:border-gold-500/50'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <motion.div 
          layout
          className="columns-1 md:columns-2 lg:columns-3 gap-6 space-y-6"
        >
          <AnimatePresence mode="popLayout">
            {filteredImages.map((img) => (
              <motion.div 
                layout
                key={img.src}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.3 }}
                className="relative group overflow-hidden rounded-2xl break-inside-avoid"
              >
                <img 
                  src={img.src} 
                  alt={img.title} 
                  className="w-full h-auto object-cover transition-transform duration-500 group-hover:scale-110" 
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-navy-900/80 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center p-6 text-center">
                  <ImageIcon className="text-gold-500 w-8 h-8 mb-2" />
                  <h4 className="text-white font-bold text-lg">{img.title}</h4>
                  <p className="text-gold-500 text-xs font-bold uppercase tracking-widest mt-1">{img.category}</p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer id="contact" className="bg-navy-900 pt-24 pb-12 border-t border-navy-800">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="space-y-6">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gold-500 rounded-lg flex items-center justify-center font-display font-bold text-navy-900 text-xl">V</div>
              <span className="font-display font-bold text-2xl text-white tracking-tight">LARA<span className="text-gold-500">.</span></span>
            </div>
            <p className="text-slate-400 text-sm leading-relaxed italic">
              Empowering students with knowledge, skills, and values to excel in the global technological landscape.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-navy-800 flex items-center justify-center text-slate-400 hover:bg-gold-500 hover:text-navy-900 transition-all"><Facebook className="w-5 h-5" /></a>
              <a href="#" className="w-10 h-10 rounded-full bg-navy-800 flex items-center justify-center text-slate-400 hover:bg-gold-500 hover:text-navy-900 transition-all"><Twitter className="w-5 h-5" /></a>
              <a href="#" className="w-10 h-10 rounded-full bg-navy-800 flex items-center justify-center text-slate-400 hover:bg-gold-500 hover:text-navy-900 transition-all"><Instagram className="w-5 h-5" /></a>
              <a href="#" className="w-10 h-10 rounded-full bg-navy-800 flex items-center justify-center text-slate-400 hover:bg-gold-500 hover:text-navy-900 transition-all"><Linkedin className="w-5 h-5" /></a>
            </div>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6 flex items-center gap-2 underline underline-offset-8 decoration-gold-500/30">Quick Links</h4>
            <ul className="space-y-4 text-sm text-slate-400">
              <li><a href="#home" className="hover:text-gold-500 transition-colors">Home</a></li>
              <li><a href="#students" className="hover:text-gold-500 transition-colors">Student Portal</a></li>
              <li><a href="#departments" className="hover:text-gold-500 transition-colors">Departments</a></li>
              <li><a href="#events" className="hover:text-gold-500 transition-colors">Events</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6 flex items-center gap-2 underline underline-offset-8 decoration-gold-500/30">Contact Us</h4>
            <ul className="space-y-4 text-sm text-slate-400">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-gold-500 shrink-0" />
                <span>Vadlamudi, Guntur, Andhra Pradesh, 522213</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-gold-500 shrink-0" />
                <span>+91 863 2347768</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-gold-500 shrink-0" />
                <span>info@vignanlara.org</span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6 flex items-center gap-2 underline underline-offset-8 decoration-gold-500/30">Newsletter</h4>
            <p className="text-slate-400 text-sm mb-4">Subscribe for campus updates.</p>
            <div className="flex gap-2">
              <input 
                type="email" 
                placeholder="Email address" 
                className="bg-navy-800 border border-navy-700 rounded-lg px-4 py-2 text-sm text-white focus:outline-none focus:border-gold-500 w-full"
              />
              <button className="bg-gold-500 text-navy-900 p-2 rounded-lg hover:bg-gold-600 transition-colors">
                <ChevronRight />
              </button>
            </div>
          </div>
        </div>

        <div className="pt-12 border-t border-navy-800 text-center text-xs text-slate-500">
          <p>© 2026 Vignan's LARA Institute of Technology and Science. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default function App() {
  const [loading, setLoading] = useState(true);

  return (
    <div className="relative overflow-x-hidden">
      <AnimatePresence>
        {loading && <SplashScreen onComplete={() => setLoading(false)} />}
      </AnimatePresence>

      {!loading && (
        <motion.main 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
          className="min-h-screen flex flex-col"
        >
          <Navbar />

          {/* Hero Section */}
          <section id="home" className="relative min-h-screen flex items-center pt-20 overflow-hidden">
            {/* Background Elements */}
            <div className="absolute inset-0 z-0">
              <div className="absolute top-1/4 -left-20 w-96 h-96 bg-gold-500/10 rounded-full blur-3xl" />
              <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-gold-500/10 rounded-full blur-3xl" />
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-from)_0%,_transparent_70%)] from-navy-800/50" />
            </div>

            <div className="container mx-auto px-6 relative z-10">
              <div className="max-w-4xl">
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  <span className="inline-block py-1 px-4 rounded-full bg-gold-500/10 text-gold-500 text-sm font-bold tracking-widest mb-6 border border-gold-500/20">
                    ESTD. 2007
                  </span>
                  <h1 className="text-5xl md:text-8xl font-bold leading-tight mb-8">
                    Shape Your Future at <br />
                    <span className="text-gold-500 gold-glow">Vignan's LARA</span>
                  </h1>
                  <p className="text-lg md:text-xl text-slate-400 mb-10 max-w-2xl leading-relaxed italic">
                    A premier institution dedicated to nurturing technical excellence and holistic development in the heart of Andhra Pradesh.
                  </p>
                  <div className="flex flex-wrap gap-6">
                    <button className="px-10 py-4 bg-gold-500 hover:bg-gold-600 text-navy-900 font-bold rounded-full transition-all transform hover:scale-105 shadow-lg shadow-gold-500/20">
                      Explore Programs
                    </button>
                    <button className="px-10 py-4 border border-slate-700 hover:border-gold-500 text-white font-bold rounded-full transition-all flex items-center gap-2 group">
                      Virtual Tour <Info className="w-5 h-5 group-hover:text-gold-500" />
                    </button>
                  </div>
                </motion.div>
              </div>
            </div>

            {/* Scroll Indicator */}
            <motion.div 
              animate={{ y: [0, 10, 0] }}
              transition={{ repeat: Infinity, duration: 2 }}
              className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-30"
            >
              <div className="w-1 h-10 bg-gradient-to-b from-gold-500 to-transparent rounded-full" />
              <span className="text-[10px] uppercase tracking-widest font-bold">Scroll</span>
            </motion.div>
          </section>

          <IDCardGenerator />
          <Departments />
          <Events />
          <Gallery />
          <Footer />
        </motion.main>
      )}
    </div>
  );
}
